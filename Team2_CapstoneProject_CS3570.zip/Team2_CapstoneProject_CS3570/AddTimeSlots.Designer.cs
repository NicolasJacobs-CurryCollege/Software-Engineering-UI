﻿namespace Team2_CapstoneProject_CS3570
{
    partial class AddTimeSlots
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TimeSlots_lbl = new Label();
            End_lbl = new Label();
            Duration_lbl = new Label();
            Beginning_lbl = new Label();
            Selectbox3 = new ListBox();
            Selectbox1 = new ListBox();
            Selectbox2 = new ListBox();
            BostonCodeCamp_lbl = new Label();
            NavigationTabs = new TabControl();
            tabPage1 = new TabPage();
            tabPage2 = new TabPage();
            tabPage3 = new TabPage();
            tabPage4 = new TabPage();
            tabPage5 = new TabPage();
            NavigationTabs.SuspendLayout();
            SuspendLayout();
            // 
            // TimeSlots_lbl
            // 
            TimeSlots_lbl.AutoSize = true;
            TimeSlots_lbl.Font = new Font("Segoe UI", 40F, FontStyle.Bold);
            TimeSlots_lbl.Location = new Point(503, 240);
            TimeSlots_lbl.Name = "TimeSlots_lbl";
            TimeSlots_lbl.Size = new Size(364, 89);
            TimeSlots_lbl.TabIndex = 39;
            TimeSlots_lbl.Text = "Time Slots";
            TimeSlots_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // End_lbl
            // 
            End_lbl.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            End_lbl.Location = new Point(918, 361);
            End_lbl.Name = "End_lbl";
            End_lbl.Size = new Size(395, 89);
            End_lbl.TabIndex = 36;
            End_lbl.Text = "End";
            End_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Duration_lbl
            // 
            Duration_lbl.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            Duration_lbl.Location = new Point(480, 531);
            Duration_lbl.Name = "Duration_lbl";
            Duration_lbl.Size = new Size(411, 89);
            Duration_lbl.TabIndex = 35;
            Duration_lbl.Text = "Duration";
            Duration_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Beginning_lbl
            // 
            Beginning_lbl.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            Beginning_lbl.Location = new Point(96, 361);
            Beginning_lbl.Name = "Beginning_lbl";
            Beginning_lbl.Size = new Size(316, 89);
            Beginning_lbl.TabIndex = 34;
            Beginning_lbl.Text = "Beginning";
            Beginning_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Selectbox3
            // 
            Selectbox3.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selectbox3.FormattingEnabled = true;
            Selectbox3.ItemHeight = 41;
            Selectbox3.Location = new Point(960, 451);
            Selectbox3.Name = "Selectbox3";
            Selectbox3.ScrollAlwaysVisible = true;
            Selectbox3.Size = new Size(316, 45);
            Selectbox3.Sorted = true;
            Selectbox3.TabIndex = 32;
            // 
            // Selectbox1
            // 
            Selectbox1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selectbox1.FormattingEnabled = true;
            Selectbox1.ItemHeight = 41;
            Selectbox1.Location = new Point(96, 451);
            Selectbox1.Name = "Selectbox1";
            Selectbox1.ScrollAlwaysVisible = true;
            Selectbox1.Size = new Size(316, 45);
            Selectbox1.Sorted = true;
            Selectbox1.TabIndex = 31;
            // 
            // Selectbox2
            // 
            Selectbox2.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selectbox2.FormattingEnabled = true;
            Selectbox2.ItemHeight = 41;
            Selectbox2.Location = new Point(528, 622);
            Selectbox2.Name = "Selectbox2";
            Selectbox2.ScrollAlwaysVisible = true;
            Selectbox2.Size = new Size(316, 45);
            Selectbox2.Sorted = true;
            Selectbox2.TabIndex = 30;
            // 
            // BostonCodeCamp_lbl
            // 
            BostonCodeCamp_lbl.AutoSize = true;
            BostonCodeCamp_lbl.Font = new Font("Segoe UI", 50F, FontStyle.Bold);
            BostonCodeCamp_lbl.Location = new Point(287, 80);
            BostonCodeCamp_lbl.Name = "BostonCodeCamp_lbl";
            BostonCodeCamp_lbl.Size = new Size(796, 112);
            BostonCodeCamp_lbl.TabIndex = 29;
            BostonCodeCamp_lbl.Text = "Boston Code Camp";
            // 
            // NavigationTabs
            // 
            NavigationTabs.Appearance = TabAppearance.Buttons;
            NavigationTabs.Controls.Add(tabPage1);
            NavigationTabs.Controls.Add(tabPage2);
            NavigationTabs.Controls.Add(tabPage3);
            NavigationTabs.Controls.Add(tabPage4);
            NavigationTabs.Controls.Add(tabPage5);
            NavigationTabs.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            NavigationTabs.Location = new Point(262, 12);
            NavigationTabs.Name = "NavigationTabs";
            NavigationTabs.SelectedIndex = 0;
            NavigationTabs.Size = new Size(846, 42);
            NavigationTabs.TabIndex = 52;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = SystemColors.Control;
            tabPage1.ForeColor = SystemColors.ControlText;
            tabPage1.Location = new Point(4, 47);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(838, 0);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "LoginPage";
            // 
            // tabPage2
            // 
            tabPage2.Location = new Point(4, 47);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(838, 0);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "SessionsPage";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            tabPage3.Location = new Point(4, 47);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(838, 0);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "AddSpeaker&Info";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            tabPage4.Location = new Point(4, 47);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(838, 0);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "AddTimeSlots";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            tabPage5.Location = new Point(4, 47);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(838, 0);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "AddRoom";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // AddTimeSlots
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PowderBlue;
            ClientSize = new Size(1370, 753);
            Controls.Add(NavigationTabs);
            Controls.Add(TimeSlots_lbl);
            Controls.Add(End_lbl);
            Controls.Add(Duration_lbl);
            Controls.Add(Beginning_lbl);
            Controls.Add(Selectbox3);
            Controls.Add(Selectbox1);
            Controls.Add(Selectbox2);
            Controls.Add(BostonCodeCamp_lbl);
            Name = "AddTimeSlots";
            Text = "AddTimeSlots";
            Load += AddTimeSlots_Load;
            NavigationTabs.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label TimeSlots_lbl;
        private Label End_lbl;
        private Label Duration_lbl;
        private Label Beginning_lbl;
        private ListBox Selectbox3;
        private ListBox Selectbox1;
        private ListBox Selectbox2;
        private Label BostonCodeCamp_lbl;
        private TabControl NavigationTabs;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private TabPage tabPage5;
    }
}