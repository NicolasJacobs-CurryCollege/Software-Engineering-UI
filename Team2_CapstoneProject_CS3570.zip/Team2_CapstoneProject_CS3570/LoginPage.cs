namespace Team2_CapstoneProject_CS3570
{
    public partial class LoginPage : Form
    {
        public LoginPage()
        {
            InitializeComponent();

            // Set up a larger TextBox above the ListBox (Selectbox1) with bigger font
            TextBox inputTextBox = new TextBox
            {
                Location = new Point(Selectbox1.Location.X, Selectbox1.Location.Y - 60),  // Position higher above ListBox
                Width = Selectbox1.Width,  // Keep TextBox width same as ListBox
                Height = 45,  // Increase TextBox height for better visibility
                Multiline = true,  // Allow multiple lines of text
                Font = new Font("Microsoft Sans Serif", 20, FontStyle.Bold)  // Set large, bold font for visibility
            };

            Controls.Add(inputTextBox);  // Add the TextBox to the form

            // Add event to handle pressing Enter in the TextBox
            inputTextBox.KeyDown += (sender, e) =>
            {
                if (e.KeyCode == Keys.Enter && !string.IsNullOrWhiteSpace(inputTextBox.Text))
                {
                    // Add TextBox content to ListBox
                    Selectbox1.Items.Add(inputTextBox.Text);
                    inputTextBox.Clear();  // Clear the TextBox for next input
                    e.SuppressKeyPress = true;  // Prevent Enter key beep sound
                }
            };
        }

        // Save ListBox content only when the form is closing
        private void LoginPage_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Save ListBox content to file only when form is closing
            string[] items = Selectbox1.Items.Cast<string>().ToArray();
            System.IO.File.WriteAllLines("listBoxContent.txt", items);
        }

        private void LoginPage_Load(object sender, EventArgs e)
        {
            // Handle form load (if needed for future features)
        }

        private void BostonCodeCamp_lbl_Click(object sender, EventArgs e)
        {

        }
    }
}
