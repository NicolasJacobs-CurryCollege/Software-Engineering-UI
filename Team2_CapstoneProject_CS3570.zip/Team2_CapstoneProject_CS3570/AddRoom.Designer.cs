﻿namespace Team2_CapstoneProject_CS3570
{
    partial class AddRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Room_lbl = new Label();
            CapacitySeating_lbl = new Label();
            RoomID_lbl = new Label();
            Selectbox2 = new ListBox();
            Selectbox1 = new ListBox();
            BostonCodeCamp_lbl = new Label();
            NavigationTabs = new TabControl();
            tabPage1 = new TabPage();
            tabPage2 = new TabPage();
            tabPage3 = new TabPage();
            tabPage4 = new TabPage();
            tabPage5 = new TabPage();
            NavigationTabs.SuspendLayout();
            SuspendLayout();
            // 
            // Room_lbl
            // 
            Room_lbl.AutoSize = true;
            Room_lbl.Font = new Font("Segoe UI", 40F, FontStyle.Bold);
            Room_lbl.Location = new Point(574, 250);
            Room_lbl.Name = "Room_lbl";
            Room_lbl.Size = new Size(223, 89);
            Room_lbl.TabIndex = 48;
            Room_lbl.Text = "Room";
            Room_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // CapacitySeating_lbl
            // 
            CapacitySeating_lbl.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            CapacitySeating_lbl.Location = new Point(727, 429);
            CapacitySeating_lbl.Name = "CapacitySeating_lbl";
            CapacitySeating_lbl.Size = new Size(395, 89);
            CapacitySeating_lbl.TabIndex = 47;
            CapacitySeating_lbl.Text = "Capacity Seating";
            CapacitySeating_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // RoomID_lbl
            // 
            RoomID_lbl.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            RoomID_lbl.Location = new Point(285, 430);
            RoomID_lbl.Name = "RoomID_lbl";
            RoomID_lbl.Size = new Size(316, 89);
            RoomID_lbl.TabIndex = 45;
            RoomID_lbl.Text = "Room ID";
            RoomID_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Selectbox2
            // 
            Selectbox2.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selectbox2.FormattingEnabled = true;
            Selectbox2.ItemHeight = 41;
            Selectbox2.Location = new Point(767, 520);
            Selectbox2.Name = "Selectbox2";
            Selectbox2.ScrollAlwaysVisible = true;
            Selectbox2.Size = new Size(316, 45);
            Selectbox2.Sorted = true;
            Selectbox2.TabIndex = 44;
            // 
            // Selectbox1
            // 
            Selectbox1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selectbox1.FormattingEnabled = true;
            Selectbox1.ItemHeight = 41;
            Selectbox1.Location = new Point(285, 520);
            Selectbox1.Name = "Selectbox1";
            Selectbox1.ScrollAlwaysVisible = true;
            Selectbox1.Size = new Size(316, 45);
            Selectbox1.Sorted = true;
            Selectbox1.TabIndex = 43;
            // 
            // BostonCodeCamp_lbl
            // 
            BostonCodeCamp_lbl.AutoSize = true;
            BostonCodeCamp_lbl.Font = new Font("Segoe UI", 50F, FontStyle.Bold);
            BostonCodeCamp_lbl.Location = new Point(298, 80);
            BostonCodeCamp_lbl.Name = "BostonCodeCamp_lbl";
            BostonCodeCamp_lbl.Size = new Size(796, 112);
            BostonCodeCamp_lbl.TabIndex = 41;
            BostonCodeCamp_lbl.Text = "Boston Code Camp";
            // 
            // NavigationTabs
            // 
            NavigationTabs.Appearance = TabAppearance.Buttons;
            NavigationTabs.Controls.Add(tabPage1);
            NavigationTabs.Controls.Add(tabPage2);
            NavigationTabs.Controls.Add(tabPage3);
            NavigationTabs.Controls.Add(tabPage4);
            NavigationTabs.Controls.Add(tabPage5);
            NavigationTabs.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            NavigationTabs.Location = new Point(262, 12);
            NavigationTabs.Name = "NavigationTabs";
            NavigationTabs.SelectedIndex = 0;
            NavigationTabs.Size = new Size(846, 42);
            NavigationTabs.TabIndex = 52;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = SystemColors.Control;
            tabPage1.ForeColor = SystemColors.ControlText;
            tabPage1.Location = new Point(4, 47);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(838, 0);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "LoginPage";
            // 
            // tabPage2
            // 
            tabPage2.Location = new Point(4, 47);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(838, 0);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "SessionsPage";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            tabPage3.Location = new Point(4, 47);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(838, 0);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "AddSpeaker&Info";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            tabPage4.Location = new Point(4, 47);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(838, 0);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "AddTimeSlots";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            tabPage5.Location = new Point(4, 47);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(838, 0);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "AddRoom";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // AddRoom
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PowderBlue;
            ClientSize = new Size(1370, 753);
            Controls.Add(NavigationTabs);
            Controls.Add(Room_lbl);
            Controls.Add(CapacitySeating_lbl);
            Controls.Add(RoomID_lbl);
            Controls.Add(Selectbox2);
            Controls.Add(Selectbox1);
            Controls.Add(BostonCodeCamp_lbl);
            Name = "AddRoom";
            Text = "AddRoom";
            Load += AddRoom_Load;
            NavigationTabs.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label Room_lbl;
        private Label CapacitySeating_lbl;
        private Label RoomID_lbl;
        private ListBox Selectbox2;
        private ListBox Selectbox1;
        private Label BostonCodeCamp_lbl;
        private TabControl NavigationTabs;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private TabPage tabPage5;
    }
}