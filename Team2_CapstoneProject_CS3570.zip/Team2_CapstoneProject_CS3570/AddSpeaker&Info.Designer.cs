﻿namespace Team2_CapstoneProject_CS3570
{
    partial class AddSpeaker_Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Speaker_lbl = new Label();
            DayofContactInfo_lbl = new Label();
            Bio_lbl = new Label();
            PhoneNumber_lbl = new Label();
            SpeakerName_lbl = new Label();
            Email_lbl = new Label();
            Selectbox4 = new ListBox();
            Selectbox3 = new ListBox();
            Selectbox1 = new ListBox();
            Selectbox2 = new ListBox();
            BostonCodeCamp_lbl = new Label();
            Bio_grpBx = new GroupBox();
            NavigationTabs = new TabControl();
            tabPage1 = new TabPage();
            tabPage2 = new TabPage();
            tabPage3 = new TabPage();
            tabPage4 = new TabPage();
            tabPage5 = new TabPage();
            NavigationTabs.SuspendLayout();
            SuspendLayout();
            // 
            // Speaker_lbl
            // 
            Speaker_lbl.AutoSize = true;
            Speaker_lbl.Font = new Font("Segoe UI", 40F, FontStyle.Bold);
            Speaker_lbl.Location = new Point(541, 197);
            Speaker_lbl.Name = "Speaker_lbl";
            Speaker_lbl.Size = new Size(289, 89);
            Speaker_lbl.TabIndex = 27;
            Speaker_lbl.Text = "Speaker";
            Speaker_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // DayofContactInfo_lbl
            // 
            DayofContactInfo_lbl.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            DayofContactInfo_lbl.Location = new Point(827, 555);
            DayofContactInfo_lbl.Name = "DayofContactInfo_lbl";
            DayofContactInfo_lbl.Size = new Size(421, 89);
            DayofContactInfo_lbl.TabIndex = 26;
            DayofContactInfo_lbl.Text = "Day of Contact Info";
            DayofContactInfo_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Bio_lbl
            // 
            Bio_lbl.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            Bio_lbl.Location = new Point(203, 555);
            Bio_lbl.Name = "Bio_lbl";
            Bio_lbl.Size = new Size(251, 67);
            Bio_lbl.TabIndex = 25;
            Bio_lbl.Text = "Bio";
            Bio_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // PhoneNumber_lbl
            // 
            PhoneNumber_lbl.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            PhoneNumber_lbl.Location = new Point(852, 428);
            PhoneNumber_lbl.Name = "PhoneNumber_lbl";
            PhoneNumber_lbl.Size = new Size(376, 72);
            PhoneNumber_lbl.TabIndex = 24;
            PhoneNumber_lbl.Text = "Phone Number";
            PhoneNumber_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // SpeakerName_lbl
            // 
            SpeakerName_lbl.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            SpeakerName_lbl.Location = new Point(480, 290);
            SpeakerName_lbl.Name = "SpeakerName_lbl";
            SpeakerName_lbl.Size = new Size(411, 89);
            SpeakerName_lbl.TabIndex = 23;
            SpeakerName_lbl.Text = "Speaker Name";
            SpeakerName_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Email_lbl
            // 
            Email_lbl.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            Email_lbl.Location = new Point(111, 428);
            Email_lbl.Name = "Email_lbl";
            Email_lbl.Size = new Size(440, 72);
            Email_lbl.TabIndex = 22;
            Email_lbl.Text = "Email";
            Email_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Selectbox4
            // 
            Selectbox4.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selectbox4.FormattingEnabled = true;
            Selectbox4.ItemHeight = 41;
            Selectbox4.Location = new Point(882, 645);
            Selectbox4.Name = "Selectbox4";
            Selectbox4.ScrollAlwaysVisible = true;
            Selectbox4.Size = new Size(316, 45);
            Selectbox4.Sorted = true;
            Selectbox4.TabIndex = 21;
            // 
            // Selectbox3
            // 
            Selectbox3.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selectbox3.FormattingEnabled = true;
            Selectbox3.ItemHeight = 41;
            Selectbox3.Location = new Point(882, 501);
            Selectbox3.Name = "Selectbox3";
            Selectbox3.ScrollAlwaysVisible = true;
            Selectbox3.Size = new Size(316, 45);
            Selectbox3.Sorted = true;
            Selectbox3.TabIndex = 19;
            // 
            // Selectbox1
            // 
            Selectbox1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selectbox1.FormattingEnabled = true;
            Selectbox1.ItemHeight = 41;
            Selectbox1.Location = new Point(172, 501);
            Selectbox1.Name = "Selectbox1";
            Selectbox1.ScrollAlwaysVisible = true;
            Selectbox1.Size = new Size(316, 45);
            Selectbox1.Sorted = true;
            Selectbox1.TabIndex = 18;
            // 
            // Selectbox2
            // 
            Selectbox2.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selectbox2.FormattingEnabled = true;
            Selectbox2.ItemHeight = 41;
            Selectbox2.Location = new Point(527, 380);
            Selectbox2.Name = "Selectbox2";
            Selectbox2.ScrollAlwaysVisible = true;
            Selectbox2.Size = new Size(316, 45);
            Selectbox2.Sorted = true;
            Selectbox2.TabIndex = 17;
            // 
            // BostonCodeCamp_lbl
            // 
            BostonCodeCamp_lbl.AutoSize = true;
            BostonCodeCamp_lbl.Font = new Font("Segoe UI", 50F, FontStyle.Bold);
            BostonCodeCamp_lbl.Location = new Point(287, 80);
            BostonCodeCamp_lbl.Name = "BostonCodeCamp_lbl";
            BostonCodeCamp_lbl.Size = new Size(796, 112);
            BostonCodeCamp_lbl.TabIndex = 16;
            BostonCodeCamp_lbl.Text = "Boston Code Camp";
            // 
            // Bio_grpBx
            // 
            Bio_grpBx.BackColor = SystemColors.ButtonHighlight;
            Bio_grpBx.Location = new Point(204, 625);
            Bio_grpBx.Name = "Bio_grpBx";
            Bio_grpBx.Size = new Size(250, 125);
            Bio_grpBx.TabIndex = 28;
            Bio_grpBx.TabStop = false;
            // 
            // NavigationTabs
            // 
            NavigationTabs.Appearance = TabAppearance.Buttons;
            NavigationTabs.Controls.Add(tabPage1);
            NavigationTabs.Controls.Add(tabPage2);
            NavigationTabs.Controls.Add(tabPage3);
            NavigationTabs.Controls.Add(tabPage4);
            NavigationTabs.Controls.Add(tabPage5);
            NavigationTabs.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            NavigationTabs.Location = new Point(262, 12);
            NavigationTabs.Name = "NavigationTabs";
            NavigationTabs.SelectedIndex = 0;
            NavigationTabs.Size = new Size(846, 42);
            NavigationTabs.TabIndex = 52;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = SystemColors.Control;
            tabPage1.ForeColor = SystemColors.ControlText;
            tabPage1.Location = new Point(4, 47);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(838, 0);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "LoginPage";
            // 
            // tabPage2
            // 
            tabPage2.Location = new Point(4, 47);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(838, 0);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "SessionsPage";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            tabPage3.Location = new Point(4, 47);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(838, 0);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "AddSpeaker&Info";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            tabPage4.Location = new Point(4, 47);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(838, 0);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "AddTimeSlots";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            tabPage5.Location = new Point(4, 47);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(838, 0);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "AddRoom";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // AddSpeaker_Info
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PowderBlue;
            ClientSize = new Size(1370, 753);
            Controls.Add(NavigationTabs);
            Controls.Add(Bio_grpBx);
            Controls.Add(Speaker_lbl);
            Controls.Add(DayofContactInfo_lbl);
            Controls.Add(Bio_lbl);
            Controls.Add(PhoneNumber_lbl);
            Controls.Add(SpeakerName_lbl);
            Controls.Add(Email_lbl);
            Controls.Add(Selectbox4);
            Controls.Add(Selectbox3);
            Controls.Add(Selectbox1);
            Controls.Add(Selectbox2);
            Controls.Add(BostonCodeCamp_lbl);
            Name = "AddSpeaker_Info";
            Text = "AddSpeaker_Info";
            Load += AddSpeaker_Info_Load;
            NavigationTabs.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Speaker_lbl;
        private Label DayofContactInfo_lbl;
        private Label Bio_lbl;
        private Label PhoneNumber_lbl;
        private Label SpeakerName_lbl;
        private Label Email_lbl;
        private ListBox Selectbox4;
        private ListBox Selectbox3;
        private ListBox Selectbox1;
        private ListBox Selectbox2;
        private Label BostonCodeCamp_lbl;
        private GroupBox Bio_grpBx;
        private TabControl NavigationTabs;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private TabPage tabPage5;
    }
}