﻿namespace Team2_CapstoneProject_CS3570
{
    partial class AddSpeaker_Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            Selectbox4 = new ListBox();
            Selectbox3 = new ListBox();
            Selectbox1 = new ListBox();
            Selectbox2 = new ListBox();
            label1 = new Label();
            groupBox1 = new GroupBox();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            tabPage2 = new TabPage();
            tabPage3 = new TabPage();
            tabPage4 = new TabPage();
            tabPage5 = new TabPage();
            tabControl1.SuspendLayout();
            SuspendLayout();
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 40F, FontStyle.Bold);
            label7.Location = new Point(541, 197);
            label7.Name = "label7";
            label7.Size = new Size(289, 89);
            label7.TabIndex = 27;
            label7.Text = "Speaker";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            label6.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            label6.Location = new Point(827, 555);
            label6.Name = "label6";
            label6.Size = new Size(421, 89);
            label6.TabIndex = 26;
            label6.Text = "Day of Contact Info";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            label5.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            label5.Location = new Point(203, 555);
            label5.Name = "label5";
            label5.Size = new Size(251, 89);
            label5.TabIndex = 25;
            label5.Text = "Bio";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            label4.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            label4.Location = new Point(852, 428);
            label4.Name = "label4";
            label4.Size = new Size(376, 72);
            label4.TabIndex = 24;
            label4.Text = "Phone Number";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            label3.Location = new Point(480, 290);
            label3.Name = "label3";
            label3.Size = new Size(411, 89);
            label3.TabIndex = 23;
            label3.Text = "Speaker Name";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            label2.Location = new Point(111, 428);
            label2.Name = "label2";
            label2.Size = new Size(440, 72);
            label2.TabIndex = 22;
            label2.Text = "Email";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Selectbox4
            // 
            Selectbox4.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selectbox4.FormattingEnabled = true;
            Selectbox4.ItemHeight = 41;
            Selectbox4.Location = new Point(882, 645);
            Selectbox4.Name = "Selectbox4";
            Selectbox4.ScrollAlwaysVisible = true;
            Selectbox4.Size = new Size(316, 45);
            Selectbox4.Sorted = true;
            Selectbox4.TabIndex = 21;
            // 
            // Selectbox3
            // 
            Selectbox3.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selectbox3.FormattingEnabled = true;
            Selectbox3.ItemHeight = 41;
            Selectbox3.Location = new Point(882, 501);
            Selectbox3.Name = "Selectbox3";
            Selectbox3.ScrollAlwaysVisible = true;
            Selectbox3.Size = new Size(316, 45);
            Selectbox3.Sorted = true;
            Selectbox3.TabIndex = 19;
            // 
            // Selectbox1
            // 
            Selectbox1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selectbox1.FormattingEnabled = true;
            Selectbox1.ItemHeight = 41;
            Selectbox1.Location = new Point(172, 501);
            Selectbox1.Name = "Selectbox1";
            Selectbox1.ScrollAlwaysVisible = true;
            Selectbox1.Size = new Size(316, 45);
            Selectbox1.Sorted = true;
            Selectbox1.TabIndex = 18;
            // 
            // Selectbox2
            // 
            Selectbox2.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selectbox2.FormattingEnabled = true;
            Selectbox2.ItemHeight = 41;
            Selectbox2.Location = new Point(527, 380);
            Selectbox2.Name = "Selectbox2";
            Selectbox2.ScrollAlwaysVisible = true;
            Selectbox2.Size = new Size(316, 45);
            Selectbox2.Sorted = true;
            Selectbox2.TabIndex = 17;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 50F, FontStyle.Bold);
            label1.Location = new Point(287, 80);
            label1.Name = "label1";
            label1.Size = new Size(796, 112);
            label1.TabIndex = 16;
            label1.Text = "Boston Code Camp";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ButtonHighlight;
            groupBox1.Location = new Point(204, 625);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(250, 125);
            groupBox1.TabIndex = 28;
            groupBox1.TabStop = false;
            // 
            // tabControl1
            // 
            tabControl1.Appearance = TabAppearance.Buttons;
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Controls.Add(tabPage5);
            tabControl1.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            tabControl1.Location = new Point(262, 12);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(846, 42);
            tabControl1.TabIndex = 52;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = SystemColors.Control;
            tabPage1.ForeColor = SystemColors.ControlText;
            tabPage1.Location = new Point(4, 47);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(838, 0);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "LoginPage";
            // 
            // tabPage2
            // 
            tabPage2.Location = new Point(4, 47);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(838, 0);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "SessionsPage";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            tabPage3.Location = new Point(4, 47);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(838, 0);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "AddSpeaker&Info";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            tabPage4.Location = new Point(4, 47);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(838, 0);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "AddTimeSlots";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            tabPage5.Location = new Point(4, 47);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(838, 0);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "AddRoom";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // AddSpeaker_Info
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PowderBlue;
            ClientSize = new Size(1370, 753);
            Controls.Add(tabControl1);
            Controls.Add(groupBox1);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(Selectbox4);
            Controls.Add(Selectbox3);
            Controls.Add(Selectbox1);
            Controls.Add(Selectbox2);
            Controls.Add(label1);
            Name = "AddSpeaker_Info";
            Text = "AddSpeaker_Info";
            tabControl1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private ListBox Selectbox4;
        private ListBox Selectbox3;
        private ListBox Selectbox1;
        private ListBox Selectbox2;
        private Label label1;
        private GroupBox groupBox1;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private TabPage tabPage5;
    }
}