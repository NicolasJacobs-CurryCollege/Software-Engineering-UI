﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace Team2_CapstoneProject_CS3570
{
    public partial class AddSpeaker_Info : Form
    {
        public AddSpeaker_Info()
        {
            InitializeComponent();

            // Create TextBoxes and ListBoxes below their corresponding labels with consistent vertical spacing
            CreateInputField(Email_lbl, Selectbox1, 1);
            CreateInputField(SpeakerName_lbl, Selectbox2, 2);
            CreateInputField(PhoneNumber_lbl, Selectbox3, 3);
            CreateInputField(DayofContactInfo_lbl, Selectbox4, 4);
        }

        private void CreateInputField(Label label, ListBox selectbox, int boxNumber)
        {
            // Set a consistent vertical spacing between each Label and TextBox
            const int verticalSpacing = 10;  // Set the gap between Label and TextBox

            // Create TextBox for each input field
            TextBox inputTextBox = new TextBox
            {
                Location = new Point(selectbox.Location.X, label.Location.Y + label.Height + verticalSpacing),  // Position below the label
                Width = selectbox.Width,  // Same width as the ListBox
                Height = 45,  // Consistent height for all TextBoxes
                Multiline = true,  // Allow multiple lines for text input
                Font = new Font("Microsoft Sans Serif", 12, FontStyle.Regular)  // Consistent font style
            };

            // Add the TextBox to the form
            Controls.Add(inputTextBox);

            // Ensure the TextBox is in front of other controls
            inputTextBox.BringToFront();

            // Add event to handle Enter key
            inputTextBox.KeyDown += (sender, e) =>
            {
                if (e.KeyCode == Keys.Enter && !string.IsNullOrWhiteSpace(inputTextBox.Text))
                {
                    // Add TextBox content to the corresponding ListBox
                    switch (boxNumber)
                    {
                        case 1:
                            Selectbox1.Items.Add(inputTextBox.Text);
                            break;
                        case 2:
                            Selectbox2.Items.Add(inputTextBox.Text);
                            break;
                        case 3:
                            Selectbox3.Items.Add(inputTextBox.Text);
                            break;
                        case 4:
                            Selectbox4.Items.Add(inputTextBox.Text);
                            break;
                    }
                    inputTextBox.Clear();  // Clear the TextBox for the next input
                    e.SuppressKeyPress = true;  // Prevent Enter key beep sound
                }
            };

            // Create ListBox below the TextBox (for storing the input)
            selectbox.Location = new Point(inputTextBox.Location.X, inputTextBox.Location.Y + inputTextBox.Height + verticalSpacing);
            selectbox.Width = inputTextBox.Width;  // Same width as TextBox
            selectbox.Height = 100;  // Set ListBox height to match the layout
            Controls.Add(selectbox);  // Add ListBox to the form
        }

        // Save ListBox content only when the form is closing
        private void AddSpeaker_Info_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Save ListBox content to file only when form is closing
            string[] items1 = Selectbox1.Items.Cast<string>().ToArray();
            string[] items2 = Selectbox2.Items.Cast<string>().ToArray();
            string[] items3 = Selectbox3.Items.Cast<string>().ToArray();
            string[] items4 = Selectbox4.Items.Cast<string>().ToArray();

            // Save to individual files or combine them as needed
            System.IO.File.WriteAllLines("Selectbox1Content.txt", items1);
            System.IO.File.WriteAllLines("Selectbox2Content.txt", items2);
            System.IO.File.WriteAllLines("Selectbox3Content.txt", items3);
            System.IO.File.WriteAllLines("Selectbox4Content.txt", items4);
        }

        private void AddSpeaker_Info_Load(object sender, EventArgs e)
        {
            // Handle form load (if needed for future features)
        }
    }
}
