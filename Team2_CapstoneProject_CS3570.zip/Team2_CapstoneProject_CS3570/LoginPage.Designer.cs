﻿namespace Team2_CapstoneProject_CS3570
{
    partial class LoginPage
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BostonCodeCamp_lbl = new Label();
            Selectbox1 = new ListBox();
            SelectCodeCampNumber_lbl = new Label();
            NavigationTabs = new TabControl();
            tabPage1 = new TabPage();
            tabPage2 = new TabPage();
            tabPage3 = new TabPage();
            tabPage4 = new TabPage();
            tabPage5 = new TabPage();
            NavigationTabs.SuspendLayout();
            SuspendLayout();
            // 
            // BostonCodeCamp_lbl
            // 
            BostonCodeCamp_lbl.AutoSize = true;
            BostonCodeCamp_lbl.Font = new Font("Segoe UI", 50F, FontStyle.Bold);
            BostonCodeCamp_lbl.Location = new Point(287, 80);
            BostonCodeCamp_lbl.Name = "BostonCodeCamp_lbl";
            BostonCodeCamp_lbl.Size = new Size(796, 112);
            BostonCodeCamp_lbl.TabIndex = 0;
            BostonCodeCamp_lbl.Text = "Boston Code Camp";
            BostonCodeCamp_lbl.TextAlign = ContentAlignment.MiddleCenter;
            BostonCodeCamp_lbl.Click += label1_Click;
            // 
            // Selectbox1
            // 
            Selectbox1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Selectbox1.FormattingEnabled = true;
            Selectbox1.ItemHeight = 41;
            Selectbox1.Location = new Point(527, 550);
            Selectbox1.Name = "Selectbox1";
            Selectbox1.ScrollAlwaysVisible = true;
            Selectbox1.Size = new Size(316, 45);
            Selectbox1.Sorted = true;
            Selectbox1.TabIndex = 1;
            Selectbox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // SelectCodeCampNumber_lbl
            // 
            SelectCodeCampNumber_lbl.AutoSize = true;
            SelectCodeCampNumber_lbl.Font = new Font("Segoe UI", 40F, FontStyle.Bold);
            SelectCodeCampNumber_lbl.Location = new Point(245, 310);
            SelectCodeCampNumber_lbl.Name = "SelectCodeCampNumber_lbl";
            SelectCodeCampNumber_lbl.Size = new Size(880, 89);
            SelectCodeCampNumber_lbl.TabIndex = 3;
            SelectCodeCampNumber_lbl.Text = "Select Code Camp Number";
            SelectCodeCampNumber_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // NavigationTabs
            // 
            NavigationTabs.Appearance = TabAppearance.Buttons;
            NavigationTabs.Controls.Add(tabPage1);
            NavigationTabs.Controls.Add(tabPage2);
            NavigationTabs.Controls.Add(tabPage3);
            NavigationTabs.Controls.Add(tabPage4);
            NavigationTabs.Controls.Add(tabPage5);
            NavigationTabs.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            NavigationTabs.Location = new Point(262, 12);
            NavigationTabs.Name = "NavigationTabs";
            NavigationTabs.SelectedIndex = 0;
            NavigationTabs.Size = new Size(846, 42);
            NavigationTabs.TabIndex = 52;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = SystemColors.Control;
            tabPage1.ForeColor = SystemColors.ControlText;
            tabPage1.Location = new Point(4, 47);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(838, 0);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "LoginPage";
            // 
            // tabPage2
            // 
            tabPage2.Location = new Point(4, 47);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(838, 0);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "SessionsPage";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            tabPage3.Location = new Point(4, 47);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(838, 0);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "AddSpeaker&Info";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            tabPage4.Location = new Point(4, 47);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(838, 0);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "AddTimeSlots";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            tabPage5.Location = new Point(4, 47);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(838, 0);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "AddRoom";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // LoginPage
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PowderBlue;
            ClientSize = new Size(1370, 753);
            Controls.Add(NavigationTabs);
            Controls.Add(SelectCodeCampNumber_lbl);
            Controls.Add(Selectbox1);
            Controls.Add(BostonCodeCamp_lbl);
            Name = "LoginPage";
            Text = "Login Page";
            Load += LoginPage_Load;
            NavigationTabs.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label BostonCodeCamp_lbl;
        private ListBox Selectbox1;
        private Label SelectCodeCampNumber_lbl;
        private TabControl NavigationTabs;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private TabPage tabPage5;
    }
}
